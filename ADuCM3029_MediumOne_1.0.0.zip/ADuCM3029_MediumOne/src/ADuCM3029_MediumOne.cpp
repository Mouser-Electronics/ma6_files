/*!
 *****************************************************************************
 * @file:    ADuCM3029_MediumOne.cpp
 * @brief:
 * @version: $Revision$
 * @date:    $Date$
 *-----------------------------------------------------------------------------
 *
Copyright (c) 2015-2018 Analog Devices, Inc.
All rights reserved.
Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
  - Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.
  - Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.
  - Modified versions of the software must be conspicuously marked as such.
  - This software is licensed solely and exclusively for use with processors
    manufactured by or for Analog Devices, Inc.
  - This software may not be combined or merged with other code in any manner
    that would cause the software to become subject to terms and conditions
    which differ from those listed here.
  - Neither the name of Analog Devices, Inc. nor the names of its
    contributors may be used to endorse or promote products derived
    from this software without specific prior written permission.
  - The use of this software may or may not infringe the patent rights of one
    or more patent holders.  This license does not release you from the
    requirement that you obtain separate licenses from these patent holders
    to use this software.
THIS SOFTWARE IS PROVIDED BY ANALOG DEVICES, INC. AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
NON-INFRINGEMENT, TITLE, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL ANALOG DEVICES, INC. OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, DAMAGES ARISING OUT OF
CLAIMS OF INTELLECTUAL PROPERTY RIGHTS INFRINGEMENT; PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include <sys/platform.h>
#include "adi_initialize.h"
#include "ADuCM3029_MediumOne.h"
#include <Timer.h>
#include <common.h>
#include <adi_timestamp.h>
#include <temp/adt7420/adi_adt7420.h>

using namespace adi_sensor_swpack;

/*Sensor objects*/
ADT7420			*adt7420 = new ADT7420();
Temperature		*pTemp = adt7420;
SENSOR_RESULT   eSensorResult;

sensors_data_t  data;

uint8_t valid_bytes[300];
uint32_t number_bytes;

/* Static data */
static ADI_WIFI_TCP_CONNECT_CONFIG  gTCPConnect = {
													.nLinkID = ADI_WIFI_CONNECTION_ID,
													.pType = (uint8_t *) "TCP",
													.pIP   = aMQTTBrokerIp,
													.pPort =  aMQTTBrokerPort,
													.nTCPKeepAlive = ADI_WIFI_MQTT_PUBLISHER_KEEPALIVE};

static ADI_WIFI_MQTT_CONNECT_CONFIG gMQTTConnect = {
													.nLinkID = ADI_WIFI_CONNECTION_ID,
													.nVersion = ADI_WIFI_MQTT_PUBLISHER_VERSION,
													.pName = aMQTTPublisherName,
													.nMQTTKeepAlive = ADI_WIFI_MQTT_PUBLISHER_KEEPALIVE,
													.pUsername = aMQTTUsername,
													.pPassword = aMQTTPassword};

static ADI_WIFI_PUBLISH_CONFIG 		gPublishConfig = {
		 	 	 	 	 	 	 	 	 	 	 	 .pMQTTData = (uint8_t *) &data,
		 	 	 	 	 	 	 	 	 	 	 	 .nMQTTDataSize = sizeof(ADI_DATA_PACKET),
													 .pTopic = aMQTTTopicName,
													 .nLinkID = ADI_WIFI_CONNECTION_ID,
													 .nQos = ADI_WIFI_MQTT_PUBLISER_QOS};

//-- static ADI_WIFI_SUBSCRIBE_CONFIG    gSubscribeConfig = {
//-- 													   .pTopic = aMQTTSubscribeTopic,
//-- 													   .nLinkID = ADI_WIFI_CONNECTION_ID,
//-- 													   .nQos = ADI_WIFI_MQTT_PUBLISER_QOS,
//-- 													   .nPacketId = 1};



/************************* Functions Definitions ******************************/

/* Pin muxing */
extern "C" int32_t adi_initpinmux(void);

/* Local Wi-Fi functions */
static void            InitWiFiConnection(void);
static void            adi_wifi_AplicationCallback(void * pCBParam, uint32_t nEvent, void * pArg);
static void            RepairConnection();
static void 		   Trap();

/*!
 * @brief      Application Callback
 *
 * @details    Called by the framework layer (adi_wifi_noos.c) when an event occurs.
 *
 * @param [in] pCBParam : Callback parameter (unused)
 *
 * @param [in] Event : Event of type #ADI_WIFI_AT_CMDCODE.
 *
 * @param [in] pArg : Callback argument (unused)
 *
 */
static void adi_wifi_AplicationCallback(void * pCBParam, uint32_t nEvent, void * pArg)
{
	switch (nEvent)
		{
			case CMD_NONE:
			{
				/* Read the publish Data. */
				adi_wifi_ParseSubscriberData();
				memset(valid_bytes, 0, number_bytes);
				adi_wifi_GetData(valid_bytes, &number_bytes);

				//-- /*Check name to call command*/
				//-- if(strstr((char *)&valid_bytes[4], (char *)"ADI_GreenHouse_cmd"))
				//-- {
				//-- 	Leds_Controll(strstr((char *)&valid_bytes[4], (char *)"{"));
				//-- }
				//-- break;
			}
			case CMD_HW_ERROR:
			{
			    break;
			}

			default:
				break;
		}

	return;
}

#if 0	// Not used
/*!
 * @brief      Initializes the system
 *
 * @details    This function is responsible for initializing the pinmuxing, power service
 *             and wifi subsystem. It also initializes the realtime clock for to timestamp
 *             the outgoing sensor data packets.
 */
static void InitSystem(void)
{
    ADI_PWR_RESULT  ePwr;

    /* Explicitly disable the watchdog timer */
    *pREG_WDT0_CTL = 0x0u;

    /* Pinmux */
    adi_initpinmux();

    /* Initialize clocks */
    ePwr = adi_pwr_Init();
    DEBUG_RESULT("Error initializing the power service.\r\n", ePwr, ADI_PWR_SUCCESS);

    ePwr = adi_pwr_SetClockDivider(ADI_CLOCK_HCLK, 1u);
    DEBUG_RESULT("Error configuring the core clock.\r\n", ePwr, ADI_PWR_SUCCESS);

    ePwr = adi_pwr_SetClockDivider(ADI_CLOCK_PCLK, 1u);
    DEBUG_RESULT("Error configuring the peripheral clock.\r\n", ePwr, ADI_PWR_SUCCESS);

    /* Init timestamping */
    INIT_TIME();

    DEBUG_MESSAGE("Starting MQTT publisher Wi-Fi\r\n");

}
#endif

/**
   @brief Initialize the WiFi connection

   @return void

**/
void InitWiFiConnection()
{
	ADI_WIFI_RESULT eResult;

    /* Initialize the ESP8266 Wi-Fi module */
	eResult = adi_wifi_Init(adi_wifi_AplicationCallback, NULL);
    DEBUG_RESULT("Error initializing the ESP8266 module.\r\n", eResult, ADI_WIFI_SUCCESS);

	eResult = adi_wifi_radio_TestAT();
    DEBUG_RESULT("Error testing hardware connectivity.\r\n", eResult, ADI_WIFI_SUCCESS);

	eResult = adi_wifi_radio_SetWiFiMode(1);
    DEBUG_RESULT("Error establishing a tcp connection.\r\n", eResult, ADI_WIFI_SUCCESS);

	eResult = adi_wifi_radio_DisconnectFromAP();
    DEBUG_RESULT("Error disconnecting from access point.\r\n", eResult, ADI_WIFI_SUCCESS);

	eResult = adi_wifi_radio_ConnectToAP(aWifiSSID, aWifiPassword,  NULL);
    DEBUG_RESULT("Error connecting to access point.\r\n", eResult, ADI_WIFI_SUCCESS);

	eResult = adi_wifi_radio_EstablishTCPConnection(&gTCPConnect);
    DEBUG_RESULT("Error establishing a tcp connection.\r\n", eResult, ADI_WIFI_SUCCESS);

}

#if 0	// Not used
/**
   @brief Callback function called when a command is received from the cloud.

   @param str - pointer to a constant string to get the command value

   @return void

**/
int Leds_Controll(const char *str)
{
	JsonNode *_main = json_decode(str);

	JsonNode *red = json_find_member(_main, "red");
	JsonNode *blue = json_find_member(_main, "blue");
	JsonNode *green = json_find_member(_main, "green");

	red->number_ = atof(red->string_);
	blue->number_ = atof(blue->string_);
	green->number_ = atof(green->string_);

	/*Control algorith for CN0410 led bar*/
	cn0410->Controll((float)red->number_, (float)blue->number_, (float)green->number_);

	json_delete(_main);

	return 0;
}
#endif

/*!
 * @brief      ESP8266 MQTT publisher demo using ADT7420 temperature data.
 *
 * @details    Publishes data over Wi-Fi to the broker.
 */
static void MQTTPublish(void)
{
	ADI_WIFI_RESULT eResult;
    uint32_t        nPacketId = 0u;
    uint8_t         nConnectionFailFlag;

    /* Initialize the ESP8266 Wi-Fi module and establish a TCP connection */
    DEBUG_MESSAGE("Connecting to Wi-Fi");
    InitWiFiConnection();

    /* Send MQTT "CONNECT" message to broker */
    eResult = adi_wifi_radio_MQTTConnect(&gMQTTConnect);
    //DEBUG_RESULT("Error connecting to the MQTT broker.\r\n", eResult, ADI_WIFI_SUCCESS);

    //-- eResult = adi_wifi_radio_MQTTSubscribe(&gSubscribeConfig);

    DEBUG_MESSAGE("Starting to Publish");

    gPublishConfig.nPacketId = nPacketId;

    /*enable wdt*/
    adi_wdt_Enable	(	true, NULL	);

    while(1)
    {
    	adi_wdt_Kick();
    	nConnectionFailFlag = 0;

    	/* If ping timer has expired */
    	if (adi_wifi_IsTimerDone(1u) == 1u)
    	{
    		/* Send MQTT "PINGREQ" message to broker to keep the connection alive. */
    		eResult = adi_wifi_radio_MQTTPing(ADI_WIFI_CONNECTION_ID);

    		/* Restart the ping timer */
    		if((adi_wifi_StopTimer(1u) == ADI_WIFI_SUCCESS) && (eResult == ADI_WIFI_SUCCESS))
    		{
    			if(adi_wifi_StartTimer(ADI_WIFI_MQTT_PING_TIMEOUT, 1u) != ADI_WIFI_SUCCESS)
    			{
    				DEBUG_MESSAGE("Failed to start ping timer\n");

    			}
    		}
    		else
    		{
    			DEBUG_MESSAGE("Failed to ping broker\n");
    			nConnectionFailFlag = 1;
    		}
    	}

    	/* If we did not fail to ping the broker, publish data */
    	if(nConnectionFailFlag == 0u)
    	{
    		DEBUG_MESSAGE("Publishing data..");

    		PrepareMqttPayload(&data);

    		char *payload = telemetry_serialize(&data);

    		DEBUG_MESSAGE("Payload: %s", payload);

    		gPublishConfig.pMQTTData = (uint8_t *)payload;
    		gPublishConfig.nMQTTDataSize = strlen(payload);


    		if(adi_wifi_radio_MQTTPublish(&gPublishConfig) == ADI_WIFI_FAILURE)
    		{
    			nConnectionFailFlag = 1u;
    		}
    		free(payload);
    		adi_wifi_DispatchEvents(6000);
    	}

    	/* If we failed to ping the broker or failed to publish data, check the connection */
    	if(nConnectionFailFlag == 1u)
    	{
    		DEBUG_MESSAGE("Troubleshooting failed connection..\n");
    		RepairConnection();
    	}

    	gPublishConfig.nPacketId++;
    }
}

/*!
 * @brief      Troubleshoot and attempt to fix connection
 *
 * @details    This function is called if the ESP8266 has failed to communicate with the AP or broker.
 *             It will attempt to diagnose and repair the connectivity problem.
 */
static void RepairConnection()
{
	uint8_t         nConnectionStatus;

	adi_wifi_radio_GetConnectionStatus(&nConnectionStatus);


	switch(nConnectionStatus)
	{
	/*The  Station is connected to an AP and its IP is obtained, so try to connect to broker. */
	case 2:
	{
		/* Send MQTT "CONNECT" message to broker */
		if(adi_wifi_radio_MQTTConnect(&gMQTTConnect) != ADI_WIFI_SUCCESS)
		{
			DEBUG_MESSAGE("Failed to do MQTT Connect\n");
		}
		break;
	}

	/* The  Station has created a TCP or UDP transmission so you should try to publish again. */
	case 3:
		break;

		/* The TCP or UDP transmission of Station is disconnected. So try to establish a TCP
		 * connection and then connect to the broker.
		 */
	case 4:
	{
		if(adi_wifi_radio_EstablishTCPConnection(&gTCPConnect) == ADI_WIFI_SUCCESS)
		{
			if(adi_wifi_radio_MQTTConnect(&gMQTTConnect) != ADI_WIFI_SUCCESS)
			{
				DEBUG_MESSAGE("Failed to do MQTT Connect\n");
			}
		}
		else
		{
			DEBUG_MESSAGE("Failed to establish connection to broker\n");
		}
		break;
	}
	/*The  Station does NOT connect to an AP. So try to connect to the AP. */
	case 5:
	{
		if(adi_wifi_radio_ConnectToAP(aWifiSSID, aWifiPassword,  NULL) == ADI_WIFI_SUCCESS)
		{
			if(adi_wifi_radio_EstablishTCPConnection(&gTCPConnect) == ADI_WIFI_SUCCESS)
			{
				if(adi_wifi_radio_MQTTConnect(&gMQTTConnect) != ADI_WIFI_SUCCESS)
				{
					DEBUG_MESSAGE("Failed to do MQTT Connect\n");
				}
			}
			else
			{
				DEBUG_MESSAGE("Failed to establish connection to broker\n");
			}

		}
		else
		{
			DEBUG_MESSAGE("Failed to Connect to AP\n");
		}
		break;
	}
	default:
	{
		break;
	}
	}

}

int main(int argc, char *argv[])
{
	/**
	 * Initialize managed drivers and/or services that have been added to 
	 * the project.
	 * @return zero on success 
	 */

	/* Explicitly disable the watchdog timer */
	*pREG_WDT0_CTL = 0x0u;

	adi_initComponents();

	timer_start();

	/* Pinmux */
	adi_initpinmux(); // Init port configuration for UART, SPI and I2C

	/* Init timestamping */
	INIT_TIME();

	/*Initialize the sensors*/

	/* Open Temperature sensor */
    eSensorResult = pTemp->open();

    if(eSensorResult != SENSOR_ERROR_NONE) {
        PRINT_SENSOR_ERROR(DEBUG_MESSAGE, eSensorResult);
        Trap();
    }

    /* Start measurement */
    eSensorResult = pTemp->start();

    if(pTemp->start() != SENSOR_ERROR_NONE) {
        PRINT_SENSOR_ERROR(DEBUG_MESSAGE, eSensorResult);
        Trap();
    }

	MQTTPublish(); //publish data to MQTT broker

	return 0;
}

/*!
 * @brief      Trap function
 *
 * @details    In case of catastrophic errors this function is called to block
 *             infinitely.
 */
static void Trap()
{
    while(1);
}
