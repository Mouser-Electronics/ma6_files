/* Copyright (c) 2017 Arrow Electronics, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Apache License 2.0
 * which accompanies this distribution, and is available at
 * http://apache.org/licenses/LICENSE-2.0
 * Contributors: Arrow Electronics, Inc.
 */

#include "telemetry.h"
#include <json.h>
#include "sensors_data.h"


//-- static char tmpdata[50];

char *telemetry_serialize(void *d) {
  sensors_data_t *data = (sensors_data_t *)d;

#if 1	// With event_data nested obj
  JsonNode *_node = json_mkobject();
  JsonNode *_event_data = json_mkobject();
  json_append_member(_node, TELEMETRY_EVENT_DATA, _event_data);
  json_append_member(_event_data, TELEMETRY_TEMPERATURE, json_mknumber(data->temperature));
  json_append_member(_event_data, TELEMETRY_TIMESTAMP, json_mknumber(data->timestamp));
  json_append_member(_event_data, TELEMETRY_ITERATION, json_mknumber(data->iteration));

  char *tmp = json_encode(_node);
  json_delete(_event_data);
  json_delete(_node);
  return tmp;
#endif

#if 0	// Without event_data nested obj
  JsonNode *_node = json_mkobject();
  json_append_member(_node, TELEMETRY_TEMPERATURE, json_mknumber(data->temperature));
  json_append_member(_node, TELEMETRY_TIMESTAMP, json_mknumber(data->timestamp));
  json_append_member(_event_data, TELEMETRY_ITERATION, json_mknumber(data->iteration));

  char *tmp = json_encode(_node);
  json_delete(_node);
  return tmp;
#endif
}
