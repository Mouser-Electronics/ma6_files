
#ifndef ARROW_TELEMETRY_H_
#define ARROW_TELEMETRY_H_

#if defined(__cplusplus)
extern "C" {
#endif

#define TELEMETRY_EVENT_DATA		  "event_data"
#define TELEMETRY_TEMPERATURE         "tempf"
#define TELEMETRY_TIMESTAMP			  "timestamp"
#define TELEMETRY_ITERATION			  "iteration"
    
char *telemetry_serialize(void *data);

#if defined(__cplusplus)
}
#endif

#endif /* ARROW_TELEMETRY_H_ */
